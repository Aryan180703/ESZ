export interface RatingResponse {
  id: number;
  productId: number;
  userId: number;
  starRating: number;
  review: string;
  createdAt: string;
  userName?: string;
}

export interface RatingRequest {
  productId: number;
  starRating: number;
  review: string;
}