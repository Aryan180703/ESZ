export interface RegisterDTO {
  fullName: string;
  email: string;
  mobileNumber: number;
  password: string;
}

export interface LoginDTO {
  email: string;
  password: string;
}

export interface AuthResponseDTO {
  token: string;
  role: string;
  id: number;
}

export interface ConfirmEmailRequest {
  email: string;
  otp: string;
}

export interface GenerateOtpRequest {
  email: string;
}

export interface ProfileDetails {
  id: number;
  fullName: string;
  email: string;
}

export interface ProfileResponse {
  fullName: string;
  email: string;
  about: string;
  gender: string;
  dateOfBirth: string;
  mobileNumber: number;
  emailConfirmed: boolean;
}

export interface UpdateProfileRequest {
  fullName: string;
  about: string;
  gender: string;
  mobileNumber: number;
  dateOfBirth: string;
}