export interface OrderRequest {
  cartId: number;
  addressId: number;
}

export interface OrderItemResponse {
  id: number;
  productId: number;
  productName: string;
  price: number;
  quantity: number;
}

export interface OrderResponse {
  id: number;
  customerId: number;
  addressId: number;
  totalPrice: number;
  status: string;
  orderDate: string;
  items: OrderItemResponse[];
}

export interface UpdateOrderStatusRequest {
  status: string;
}