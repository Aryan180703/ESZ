export interface AddressResponse {
  id: number;
  houseNumber: number;
  streetName: string;
  colonyName?: string;
  city: string;
  state: string;
  pincode: number;
}

export interface AddressRequest {
  houseNumber: number;
  streetName: string;
  colonyName?: string;
  city: string;
  state: string;
  pincode: number;
}