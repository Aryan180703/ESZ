export interface CartRequest {
  productId: number;
  quantity: number;
}

export interface CartItemResponse {
  id: number;
  productId: number;
  productName: string;
  price: number;
  quantity: number;
}

export interface CartResponse {
  id: number;
  totalPrice: number;
  items: CartItemResponse[];
}

export interface UpdateCartItemRequest {
  quantity: number;
}