export interface ProductRequest {
  name: string;
  type: string;
  category: string;
  price: number;
  stock: number;
  description: string;
  images: string;
  specifications: string;
}

export interface ProductResponse {
  id: number;
  name: string;
  type: string;
  category: string;
  price: number;
  stock: number;
  description: string;
  images: string;
  specifications: string;
  averageRating: number;
  reviewCount: number;
}

export interface UpdateProductRequest {
  name?: string;
  type?: string;
  category?: string;
  price?: number;
  stock?: number;
  description?: string;
  images?: string;
  specifications?: string;
}