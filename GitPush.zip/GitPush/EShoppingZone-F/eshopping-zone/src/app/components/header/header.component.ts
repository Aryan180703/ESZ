import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { RoleRequestService } from '../../services/role-request.service';
import { ResponseDTO } from '../../models/response.model';

export @Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
class HeaderComponent implements OnInit {
  isLoggedIn: boolean = false;
  userRole: string | null = null;
  userFirstName: string | null = null;
  searchQuery: string = '';
  showDropdown: boolean = false;
  showRoleDialog: boolean = false;
  showStatusDialog: boolean = false;
  roleDialogMessage: string = '';
  statusDialogMessage: string = '';
  requestedRole: string = '';
  dialogAction: 'confirm' | 'status' | null = null;

  constructor(
    private authService: AuthService,
    private roleRequestService: RoleRequestService,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.currentUser.subscribe(user => {
      this.isLoggedIn = !!user;
      this.userRole = user?.role || null;
      this.showDropdown = false;
      if (user) {
        this.authService.getUserName(user.id).subscribe({
          next: (profile) => {
            this.userFirstName = profile.fullName.split(' ')[0];
          },
          error: () => {
            this.userFirstName = 'User';
          },
        });
      }
    });
  }

  toggleDropdown() {
    this.showDropdown = !this.showDropdown;
  }

  closeDropdown() {
    this.showDropdown = false;
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (!target.closest('.dropdown')) {
      this.closeDropdown();
    }
  }

  onSearch() {
    if (this.searchQuery) {
      this.authService.search(this.searchQuery);
      this.router.navigate(['/search'], { queryParams: { q: this.searchQuery } });
    }
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  openRoleDialog(role: string) {
    this.requestedRole = role;
    this.dialogAction = 'confirm';
    this.roleDialogMessage = `Are you sure you want to become a ${role}?`;
    this.showRoleDialog = true;
  }

  confirmRoleRequest() {
    this.roleRequestService.submitRoleRequest(this.requestedRole).subscribe({
      next: (response: ResponseDTO<string>) => {
        this.showRoleDialog = false;
        this.statusDialogMessage = response.success
          ? 'Your application is being reviewed, stay tuned.'
          : response.message || 'You already have a pending request.';
        this.showStatusDialog = true;
      },
      error: (err) => {
        this.showRoleDialog = false;
        this.statusDialogMessage = 'An error occurred. Please try again.';
        this.showStatusDialog = true;
        console.error('Role request error:', err);
      },
    });
  }

  checkRoleStatus() {
    this.roleRequestService.checkRoleRequestStatus('Merchant').subscribe({
      next: (response: ResponseDTO<string>) => {
        this.statusDialogMessage = response.success
          ? response.message || 'We are reviewing your request, any update will be sent through a notification.'
          : 'No pending request.';
        this.showStatusDialog = true;
        this.dialogAction = 'status';
      },
      error: (err) => {
        this.statusDialogMessage = 'An error occurred. Please try again.';
        this.showStatusDialog = true;
        this.dialogAction = 'status';
        console.error('Role status error:', err);
      },
    });
  }

  closeDialog() {
    this.showRoleDialog = false;
    this.showStatusDialog = false;
    this.dialogAction = null;
  }

  goHome() {
    const role = this.userRole;
    if (role === 'Merchant') this.router.navigate(['/merchant/dashboard']);
    else if (role === 'Admin') this.router.navigate(['/admin/dashboard']);
    else this.router.navigate(['/']);
  }
}