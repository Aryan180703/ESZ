import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ResponseDTO } from '../../models/response.model';
import { ProductResponse } from '../../models/product.model';
import { OrderResponse } from '../../models/order.model';
import { AuthService } from '../../services/auth.service';
import {RoleRequestService} from '../../services/role-request.service';

interface UserRoleRequest {
  id: number;
  userId: number;
  requestedRole: string;
  status: string;
  requestedDate: string;
  approvedBy?: number;
  approvedDate?: string;
  userName?: string;
  createdAt?: string;
}

interface User {
  id: number;
  fullName: string;
  role: string;
  createdAt: string;
}

export @Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
})
class AdminDashboardComponent implements OnInit {
  pendingDARequests: UserRoleRequest[] = [];
  pendingMerchantRequests: UserRoleRequest[] = [];
  allDA: User[] = [];
  allMerchants: User[] = [];
  showPendingDA: boolean = false;
  showPendingMerchant: boolean = false;
  showAllDA: boolean = false;
  showAllMerchants: boolean = false;
  products: ProductResponse[] = [];
  orders: OrderResponse[] = [];
  errorMessage: string | null = null;

  constructor(
    private http: HttpClient,
    private roleRequestService: RoleRequestService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loadPendingRequests();
    this.loadAllUsers();
    this.loadProducts();
    this.loadOrders();
  }

  loadPendingRequests() {
    this.roleRequestService.getPendingRequests().subscribe({
      next: (response: ResponseDTO<UserRoleRequest[]>) => {
        if (response.success) {
          this.pendingDARequests = response.data.filter(r => r.requestedRole === 'Delivery Agent');
          this.pendingMerchantRequests = response.data.filter(r => r.requestedRole === 'Merchant');
          this.fetchUserNamesForRequests(this.pendingDARequests);
          this.fetchUserNamesForRequests(this.pendingMerchantRequests);
        } else {
          this.errorMessage = response.message;
        }
      },
      error: () => {
        this.errorMessage = 'Failed to load role requests.';
      },
    });
  }

  fetchUserNamesForRequests(requests: UserRoleRequest[]) {
    requests.forEach(request => {
      this.authService.getUserName(request.userId).subscribe({
        next: (profile) => {
          request.userName = profile.fullName;
          request.createdAt = request.requestedDate;
        },
        error: () => {
          request.userName = 'Unknown';
        },
      });
    });
  }

  loadAllUsers() {
    this.http.get<ResponseDTO<User[]>>('http://localhost:5287/api/AuthController/GetAllUsers').subscribe({
      next: (response: ResponseDTO<User[]>) => {
        if (response.success) {
          this.allDA = response.data.filter(u => u.role === 'Delivery Agent');
          this.allMerchants = response.data.filter(u => u.role === 'Merchant');
        }
      },
      error: () => {
        this.errorMessage = 'Failed to load users.';
      },
    });
  }

  loadProducts() {
    this.http.get<ResponseDTO<ProductResponse[]>>(`http://localhost:5287/api/ProductController/GetAllProducts`).subscribe({
      next: (response: ResponseDTO<ProductResponse[]>) => {
        if (response.success) {
          this.products = response.data;
        }
      },
      error: () => {
        this.errorMessage = 'Failed to load products.';
      },
    });
  }

  loadOrders() {
    this.http.get<ResponseDTO<OrderResponse[]>>(`http://localhost:5287/api/OrderController/GetAllOrders`).subscribe({
      next: (response: ResponseDTO<OrderResponse[]>) => {
        if (response.success) {
          this.orders = response.data;
        }
      },
      error: () => {
        this.errorMessage = 'Failed to load orders.';
      },
    });
  }

  togglePendingDA() {
    this.showPendingDA = !this.showPendingDA;
  }

  togglePendingMerchant() {
    this.showPendingMerchant = !this.showPendingMerchant;
  }

  toggleAllDA() {
    this.showAllDA = !this.showAllDA;
  }

  toggleAllMerchants() {
    this.showAllMerchants = !this.showAllMerchants;
  }

  approveRequest(requestId: number, isApproved: boolean) {
    this.http.post<ResponseDTO<string>>(`http://localhost:5287/api/RoleRequest/ApproveRequest`, {}, {
      params: { requestId, isApproved }
    }).subscribe({
      next: (response: ResponseDTO<string>) => {
        if (response.success) {
          this.loadPendingRequests();
          this.loadAllUsers();
        } else {
          this.errorMessage = response.message;
        }
      },
      error: () => {
        this.errorMessage = 'Failed to process request.';
      },
    });
  }
}