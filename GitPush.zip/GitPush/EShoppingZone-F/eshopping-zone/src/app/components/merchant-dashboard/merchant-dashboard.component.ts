import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import {  ProductResponse } from '../../models/product.model';
import { ResponseDTO } from '../../models/response.model';

export @Component({
  selector: 'app-merchant-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './merchant-dashboard.component.html',
  styleUrls: ['./merchant-dashboard.component.css'],
})
class MerchantDashboardComponent implements OnInit {
  products: ProductResponse[] = [];
  lowStockProducts: ProductResponse[] = [];
  errorMessage: string | null = null;
  showInventory: boolean = false;
  showLowStock: boolean = false;
  showManageProducts: boolean = false;
  editingStockId: number | null = null;
  editingStockValue: number = 0;

  constructor(private productService: ProductService, private router: Router) {}

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.productService.getMerchantProducts().subscribe({
      next: (response: ResponseDTO<ProductResponse[]>) => {
        if (response.success) {
          this.products = response.data;
          this.lowStockProducts = this.products.filter(p => p.stock < 100);
        } else {
          this.errorMessage = response.message;
        }
      },
      error: () => {
        this.errorMessage = 'Failed to load products.';
      },
    });
  }

  toggleInventory() {
    this.showInventory = !this.showInventory;
  }

  toggleLowStock() {
    this.showLowStock = !this.showLowStock;
  }

  toggleManageProducts() {
    this.showManageProducts = !this.showManageProducts;
  }

  editStock(product: ProductResponse) {
    this.editingStockId = product.id;
    this.editingStockValue = product.stock;
  }

  saveStock(productId: number) {
    this.productService.updateProduct(productId, { stock: this.editingStockValue }).subscribe({
      next: (response: ResponseDTO<ProductResponse>) => {
        if (response.success) {
          this.loadProducts();
          this.editingStockId = null;
        } else {
          this.errorMessage = response.message;
        }
      },
      error: () => {
        this.errorMessage = 'Failed to update stock.';
      },
    });
  }

  cancelEdit() {
    this.editingStockId = null;
  }

  viewProduct(id: number) {
    this.router.navigate(['/product', id]);
  }

  editProduct(id: number) {
    this.router.navigate(['/merchant/products', { id }]);
  }
}