import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { ProductRequest, ProductResponse } from '../../models/product.model';
import { ResponseDTO } from '../../models/response.model';

@Component({
  selector: 'app-merchant-product',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './merchant-product.component.html',
  styleUrls: ['./merchant-product.component.css'],
})
export class MerchantProductComponent implements OnInit {
  productForm: FormGroup;
  products: ProductResponse[] = [];
  errorMessage: string | null = null;
  successMessage: string | null = null;
  editingProductId: number | null = null;

  constructor(private fb: FormBuilder, private productService: ProductService) {
    this.productForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(100)]],
      type: ['', [Validators.maxLength(50)]],
      category: ['', [Validators.maxLength(50)]],
      price: [0, [Validators.required, Validators.min(0.01)]],
      stock: [0, [Validators.required, Validators.min(0)]],
      description: ['', [Validators.maxLength(500)]],
      images: ['', [Validators.maxLength(200)]],
      specifications: ['', [Validators.maxLength(500)]],
    });
  }

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.productService.getMerchantProducts().subscribe({
      next: (response: ResponseDTO<ProductResponse[]>) => {
        if (response.success) {
          this.products = response.data;
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  onSubmit() {
    if (this.productForm.valid) {
      const dto: ProductRequest = this.productForm.value;
      if (this.editingProductId) {
        this.productService.updateProduct(this.editingProductId, dto).subscribe({
          next: (response: ResponseDTO<ProductResponse>) => {
            if (response.success) {
              this.successMessage = 'Product updated successfully!';
              this.errorMessage = null;
              this.loadProducts();
              this.resetForm();
            } else {
              this.errorMessage = response.message;
            }
          },
        });
      } else {
        this.productService.addProduct(dto).subscribe({
          next: (response: ResponseDTO<ProductResponse>) => {
            if (response.success) {
              this.successMessage = 'Product added successfully!';
              this.errorMessage = null;
              this.loadProducts();
              this.resetForm();
            } else {
              this.errorMessage = response.message;
            }
          },
        });
      }
    }
  }

  editProduct(product: ProductResponse) {
    this.editingProductId = product.id;
    this.productForm.patchValue(product);
  }

  deleteProduct(productId: number) {
    this.productService.deleteProduct(productId).subscribe({
      next: (response: ResponseDTO<ProductResponse>) => {
        if (response.success) {
          this.successMessage = 'Product deleted successfully!';
          this.errorMessage = null;
          this.loadProducts();
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  resetForm() {
    this.productForm.reset();
    this.editingProductId = null;
  }
}