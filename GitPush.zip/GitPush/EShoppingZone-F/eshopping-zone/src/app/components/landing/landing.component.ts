import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import {  ProductResponse } from '../../models/product.model';
import { ResponseDTO } from '../../models/response.model';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css'],
})
export class LandingComponent implements OnInit {
  categories: string[] = [];
  topProducts: ProductResponse[] = [];

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private router: Router
  ) {}

  ngOnInit() {
    this.productService.getCategories().subscribe(categories => {
      this.categories = categories;
    });
    this.productService.getAllProducts().subscribe({
      next: (response: ResponseDTO<ProductResponse[]>) => {
        if (response.success) {
          this.topProducts = response.data.sort((a, b) => b.averageRating - a.averageRating).slice(0, 8);
        }
      },
    });
  }

  viewProduct(id: number) {
    this.router.navigate(['/product', id]);
  }

  addToCart(productId: number, quantity: number) {
    this.cartService.addToCart({ productId, quantity }).subscribe({
      next: (response: ResponseDTO<any>) => {
        if (response.success) {
          // Show success message or redirect to cart
        }
      },
    });
  }
}