import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ResponseDTO } from '../../models/response.model';
import { AuthResponseDTO, LoginDTO } from '../../models/auth.model';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const loginDto: LoginDTO = this.loginForm.value;
      this.authService.login(loginDto).subscribe({
        next: (response: ResponseDTO<AuthResponseDTO>) => {
          if (response.success && response.data) {
            this.successMessage = 'Login successful!';
            this.errorMessage = null;
            setTimeout(() => {
              const role = this.authService.getUserRole();
              if (role === 'Admin') this.router.navigate(['/admin/dashboard']);
              else if (role === 'Merchant') this.router.navigate(['/merchant/dashboard']);
              else if (role === 'Delivery Agent') this.router.navigate(['/delivery/dashboard']);
              else this.router.navigate(['/']);
            }, 2000);
          } else {
            this.errorMessage = response.message || 'Invalid email or password.';
            this.successMessage = null;
          }
        },
        error: (err) => {
          this.errorMessage = 'An unexpected error occurred. Please try again.';
          this.successMessage = null;
          console.error('Login error:', err);
        },
      });
    } else {
      this.errorMessage = 'Please fill out the form correctly.';
      this.successMessage = null;
    }
  }
}