import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';
import {  ProductResponse } from '../../models/product.model';
import { RatingResponse, RatingRequest } from '../../models/rating.model';
import { ResponseDTO } from '../../models/response.model';

export @Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css'],
})
class ProductDetailComponent implements OnInit {
  product: ProductResponse | null = null;
  images: string[] = [];
  currentImageIndex: number = 0;
  specifications: string[] = [];
  reviews: RatingResponse[] = [];
  newReview: RatingRequest = { productId: 0, starRating: 0, review: '' };
  quantity: number = 1;
  showLoginDialog: boolean = false;
  showReviewForm: boolean = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService,
    private cartService: CartService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    const productId = +this.route.snapshot.paramMap.get('id')!;
    this.productService.getProduct(productId).subscribe({
      next: (response: ResponseDTO<ProductResponse>) => {
        if (response.success && response.data) {
          this.product = response.data;
          this.newReview.productId = productId;
          this.images = this.product.images ? this.product.images.split(',').map(img => img.trim()) : [];
          this.specifications = this.product.specifications ? this.product.specifications.split(',').map(spec => spec.trim()) : [];
          this.loadReviews(productId);
        } else {
          this.errorMessage = response.message || 'Failed to load product.';
        }
      },
      error: () => {
        this.errorMessage = 'An error occurred while loading the product.';
      },
    });
  }

  loadReviews(productId: number) {
    this.productService.getRatingsByProduct(productId).subscribe({
      next: (response: ResponseDTO<RatingResponse[]>) => {
        if (response.success) {
          this.reviews = response.data;
          this.reviews.forEach(review => {
            this.authService.getUserName(review.userId).subscribe({
              next: (profile) => {
                review.userName = profile.fullName;
              },
            });
          });
        }
      },
      error: () => {
        this.errorMessage = 'Failed to load reviews.';
      },
    });
  }

  prevImage() {
    this.currentImageIndex = this.currentImageIndex > 0 ? this.currentImageIndex - 1 : this.images.length - 1;
  }

  nextImage() {
    this.currentImageIndex = this.currentImageIndex < this.images.length - 1 ? this.currentImageIndex + 1 : 0;
  }

  setImage(index: number) {
    this.currentImageIndex = index;
  }

  addToCart() {
    if (!this.authService.isLoggedIn()) {
      this.showLoginDialog = true;
      return;
    }
    if (this.product) {
      this.cartService.addToCart({ productId: this.product.id, quantity: this.quantity }).subscribe({
        next: (response: ResponseDTO<any>) => {
          if (response.success) {
            this.successMessage = 'Added to cart successfully!';
            this.errorMessage = null;
          } else {
            this.errorMessage = response.message || 'Failed to add to cart.';
          }
        },
        error: () => {
          this.errorMessage = 'An error occurred while adding to cart.';
        },
      });
    }
  }

  submitReview() {
    if (!this.authService.isLoggedIn()) {
      this.showLoginDialog = true;
      return;
    }
    if (this.newReview.starRating === 0 || !this.newReview.review) {
      this.errorMessage = 'Please provide a rating and review.';
      return;
    }
    this.productService.addRating(this.newReview).subscribe({
      next: (response: ResponseDTO<RatingResponse>) => {
        if (response.success) {
          this.successMessage = 'Review submitted successfully!';
          this.errorMessage = null;
          this.loadReviews(this.product!.id);
          this.showReviewForm = false;
          this.newReview = { productId: this.product!.id, starRating: 0, review: '' };
        } else {
          this.errorMessage = response.message || 'Failed to submit review.';
        }
      },
      error: () => {
        this.errorMessage = 'An error occurred while submitting the review.';
      },
    });
  }

  toggleReviewForm() {
    if (!this.authService.isLoggedIn()) {
      this.showLoginDialog = true;
    } else {
      this.showReviewForm = !this.showReviewForm;
    }
  }

  closeDialog() {
    this.showLoginDialog = false;
  }

  viewProduct(id: number) {
    this.router.navigate(['/product', id]);
  }
}