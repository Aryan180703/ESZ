import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';
import {  CartResponse } from '../../models/cart.model';
import { OrderService } from '../../services/order.service';
import { OrderRequest } from '../../models/order.model';
import { HttpClient } from '@angular/common/http';
import { AddressResponse } from '../../models/address.model';
import { ResponseDTO } from '../../models/response.model';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cart: CartResponse | null = null;
  errorMessage: string | null = null;
  successMessage: string | null = null;
  selectedAddressId: number | null = null;
  addresses: AddressResponse[] = [];

  constructor(
    private cartService: CartService,
    private authService: AuthService,
    private orderService: OrderService,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.cartService.getCart().subscribe({
      next: (response: ResponseDTO<CartResponse>) => {
        if (response.success) {
          this.cart = response.data;
        } else {
          this.errorMessage = response.message;
        }
      },
    });
    this.http.get<ResponseDTO<AddressResponse[]>>('http://localhost:5287/api/AddressController/GetAllAddress').subscribe({
      next: (response) => {
        if (response.success) {
          this.addresses = response.data;
        }
      },
    });
  }

  updateQuantity(itemId: number, quantity: number) {
    this.cartService.updateCartItem(itemId, { quantity }).subscribe({
      next: (response: ResponseDTO<CartResponse>) => {
        if (response.success) {
          this.cart = response.data;
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  removeItem(itemId: number) {
    this.cartService.removeFromCart(itemId).subscribe({
      next: (response: ResponseDTO<CartResponse>) => {
        if (response.success) {
          this.cart = response.data;
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  clearCart() {
    this.cartService.clearCart().subscribe({
      next: (response: ResponseDTO<CartResponse>) => {
        if (response.success) {
          this.cart = response.data;
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  checkout() {
    if (!this.authService.isLoggedIn()) {
      this.router.navigate(['/login']);
      return;
    }
    this.authService.isEmailVerified().subscribe(isVerified => {
      if (!isVerified) {
        this.router.navigate(['/email-verification']);
        return;
      }
      if (this.cart && this.selectedAddressId) {
        const orderRequest: OrderRequest = {
          cartId: this.cart.id,
          addressId: this.selectedAddressId,
        };
        this.orderService.placeOrder(orderRequest).subscribe({
          next: (response) => {
            if (response.success) {
              this.successMessage = 'Order placed successfully!';
              this.errorMessage = null;
              this.router.navigate(['/orders']);
            } else {
              this.errorMessage = response.message;
            }
          },
        });
      } else {
        this.errorMessage = 'Please select an address.';
      }
    });
  }
}