import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ResponseDTO } from '../../models/response.model';
import { AuthService } from '../../services/auth.service';
import { AddressResponse, AddressRequest } from '../../models/address.model';

export @Component({
  selector: 'app-address',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css'],
})
class AddressComponent implements OnInit {
  addressForm: FormGroup;
  addresses: AddressResponse[] = [];
  errorMessage: string | null = null;
  successMessage: string | null = null;
  editingAddressId: number | null = null;
  showAddForm: boolean = false;

  constructor(private fb: FormBuilder, private http: HttpClient, private authService: AuthService) {
    this.addressForm = this.fb.group({
      houseNumber: [0, [Validators.required, Validators.min(1)]],
      streetName: ['', [Validators.required, Validators.maxLength(100)]],
      colonyName: ['', [Validators.maxLength(100)]],
      city: ['', [Validators.required, Validators.maxLength(50)]],
      state: ['', [Validators.required, Validators.maxLength(50)]],
      pincode: [0, [Validators.required, Validators.pattern('^[0-9]{6}$')]],
    });
  }

  ngOnInit() {
    this.loadAddresses();
  }

  loadAddresses() {
    this.http.get<ResponseDTO<AddressResponse[]>>('http://localhost:5287/api/AddressController/GetAllAddress').subscribe({
      next: (response) => {
        if (response.success) {
          this.addresses = response.data;
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  toggleAddForm() {
    this.showAddForm = true;
    this.editingAddressId = null;
    this.addressForm.reset();
  }

  onSubmit() {
    if (this.addressForm.valid) {
      const dto: AddressRequest = this.addressForm.value;
      if (this.editingAddressId) {
        this.http.put<ResponseDTO<AddressResponse>>(`http://localhost:5287/api/AddressController/UpdateAddress/${this.editingAddressId}`, dto).subscribe({
          next: (response) => {
            if (response.success) {
              this.successMessage = 'Address updated successfully!';
              this.errorMessage = null;
              this.loadAddresses();
              this.showAddForm = false;
            } else {
              this.errorMessage = response.message;
            }
          },
        });
      } else {
        this.http.post<ResponseDTO<AddressResponse>>('http://localhost:5287/api/AddressController', dto).subscribe({
          next: (response) => {
            if (response.success) {
              this.successMessage = 'Address added successfully!';
              this.errorMessage = null;
              this.loadAddresses();
              this.showAddForm = false;
            } else {
              this.errorMessage = response.message;
            }
          },
        });
      }
    }
  }

  editAddress(address: AddressResponse) {
    this.editingAddressId = address.id;
    this.addressForm.patchValue(address);
    this.showAddForm = true;
  }

  deleteAddress(addressId: number) {
    this.http.delete<ResponseDTO<AddressResponse>>(`http://localhost:5287/api/AddressController/DeleteAddress/${addressId}`).subscribe({
      next: (response) => {
        if (response.success) {
          this.successMessage = 'Address deleted successfully!';
          this.errorMessage = null;
          this.loadAddresses();
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  cancelForm() {
    this.showAddForm = false;
    this.editingAddressId = null;
    this.addressForm.reset();
  }
}