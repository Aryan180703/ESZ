import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { OrderService } from '../../services/order.service';
import { OrderResponse, UpdateOrderStatusRequest } from '../../models/order.model';
import { ResponseDTO } from '../../models/response.model';

@Component({
  selector: 'app-delivery-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './delivery-dashboard.component.html',
  styleUrls: ['./delivery-dashboard.component.css'],
})
export class DeliveryDashboardComponent implements OnInit {
  orders: OrderResponse[] = [];
  errorMessage: string | null = null;

  constructor(private orderService: OrderService) {}

  ngOnInit() {
    this.orderService.getAllOrders().subscribe({
      next: (response: ResponseDTO<OrderResponse[]>) => {
        if (response.success) {
          this.orders = response.data;
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }

  updateStatus(orderId: number, status: string) {
    const dto: UpdateOrderStatusRequest = { status };
    this.orderService.updateOrderStatus(orderId, dto).subscribe({
      next: (response: ResponseDTO<OrderResponse>) => {
        if (response.success) {
          this.orders = this.orders.map(o => (o.id === orderId ? response.data : o));
        } else {
          this.errorMessage = response.message;
        }
      },
    });
  }
}