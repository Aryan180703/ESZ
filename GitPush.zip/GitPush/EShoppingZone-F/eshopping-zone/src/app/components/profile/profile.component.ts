import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ProfileResponse, UpdateProfileRequest } from '../../models/auth.model';
import { ResponseDTO } from '../../models/response.model';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;
  profile: ProfileResponse | null = null;
  errorMessage: string | null = null;
  successMessage: string | null = null;
  isEmailVerified: boolean = false;
  showEditForm: boolean = false;

  constructor(private fb: FormBuilder, private authService: AuthService) {
    this.profileForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.maxLength(100)]],
      about: ['', [Validators.maxLength(500)]],
      gender: ['', [Validators.required]],
      mobileNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      dateOfBirth: ['', [Validators.required]],
    });
  }

  ngOnInit() {
    this.authService.viewProfile().subscribe({
      next: (response: ResponseDTO<ProfileResponse>) => {
        if (response.success && response.data) {
          this.profile = response.data;
          this.isEmailVerified = response.data.emailConfirmed;
          this.profileForm.patchValue(this.profile);
        } else {
          this.errorMessage = response.message || 'Failed to load profile.';
        }
      },
      error: () => {
        this.errorMessage = 'Failed to load profile.';
      },
    });
  }

  toggleEditForm() {
    this.showEditForm = !this.showEditForm;
    if (!this.showEditForm && this.profile) {
      this.profileForm.patchValue(this.profile);
      this.errorMessage = null;
      this.successMessage = null;
    }
  }

  onSubmit() {
    if (this.profileForm.valid) {
      const updateDto: UpdateProfileRequest = this.profileForm.value;
      this.authService.updateProfile(updateDto).subscribe({
        next: (response: ResponseDTO<ProfileResponse>) => {
          if (response.success && response.data) {
            this.successMessage = 'Profile updated successfully!';
            this.errorMessage = null;
            this.profile = response.data;
            this.showEditForm = false;
          } else {
            this.errorMessage = response.message;
            this.successMessage = null;
          }
        },
        error: () => {
          this.errorMessage = 'An error occurred. Please try again.';
          this.successMessage = null;
        },
      });
    }
  }
}