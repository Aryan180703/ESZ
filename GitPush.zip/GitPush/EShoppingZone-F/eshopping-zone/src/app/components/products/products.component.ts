import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { ProductResponse } from '../../models/product.model';
import { ResponseDTO } from '../../models/response.model';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  products: ProductResponse[] = [];
  categories: string[] = [];
  selectedCategory: string | null = null;
  sortBy: string = 'rating';

  constructor(
    private productService: ProductService,
    private authService: AuthService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.productService.getCategories().subscribe(categories => {
      this.categories = categories;
    });
    this.route.queryParams.subscribe(params => {
      this.selectedCategory = params['category'] || null;
      this.loadProducts();
    });
    this.authService.searchQuery.subscribe(query => {
      this.loadProducts(query);
    });
  }

  loadProducts(searchQuery: string = '') {
    this.productService.getAllProducts().subscribe({
      next: (response: ResponseDTO<ProductResponse[]>) => {
        if (response.success) {
          let products = response.data;
          if (this.selectedCategory) {
            products = products.filter(p => p.category === this.selectedCategory);
          }
          if (searchQuery) {
            products = products.filter(
              p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                  (p.category && p.category.toLowerCase().includes(searchQuery.toLowerCase()))
            );
          }
          if (this.sortBy === 'rating') {
            products.sort((a, b) => b.averageRating - a.averageRating);
          } else if (this.sortBy === 'price') {
            products.sort((a, b) => a.price - b.price);
          }
          this.products = products;
        }
      },
    });
  }

  onSortChange(event: Event) {
    this.sortBy = (event.target as HTMLSelectElement).value;
    this.loadProducts();
  }
}