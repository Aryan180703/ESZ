import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ConfirmEmailRequest, GenerateOtpRequest } from '../../models/auth.model';
import { ResponseDTO } from '../../models/response.model';

@Component({
  selector: 'app-email-verification',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './email-verification.component.html',
  styleUrls: ['./email-verification.component.css'],
})
export class EmailVerificationComponent {
  verificationForm: FormGroup;
  otpForm: FormGroup;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.verificationForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
    });
    this.otpForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      otp: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
    });
  }

  onGenerateOtp() {
    if (this.verificationForm.valid) {
      const dto: GenerateOtpRequest = this.verificationForm.value;
      this.authService.generateOtp(dto).subscribe({
        next: (response: ResponseDTO<string>) => {
          if (response.success) {
            this.successMessage = 'OTP sent to your email!';
            this.errorMessage = null;
            this.otpForm.patchValue({ email: this.verificationForm.value.email });
          } else {
            this.errorMessage = response.message;
            this.successMessage = null;
          }
        },
        error: () => {
          this.errorMessage = 'An error occurred. Please try again.';
          this.successMessage = null;
        },
      });
    }
  }

  onVerifyOtp() {
    if (this.otpForm.valid) {
      const dto: ConfirmEmailRequest = this.otpForm.value;
      this.authService.confirmEmail(dto).subscribe({
        next: (response: ResponseDTO<string>) => {
          if (response.success) {
            this.successMessage = 'Email verified successfully!';
            this.errorMessage = null;
            this.router.navigate(['/']);
          } else {
            this.errorMessage = response.message;
            this.successMessage = null;
          }
        },
        error: () => {
          this.errorMessage = 'An error occurred. Please try again.';
          this.successMessage = null;
        },
      });
    }
  }

  skipVerification() {
    this.router.navigate(['']);
  }
}