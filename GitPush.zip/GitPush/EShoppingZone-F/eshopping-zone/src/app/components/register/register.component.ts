import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ResponseDTO } from '../../models/response.model';
import { AuthResponseDTO, RegisterDTO } from '../../models/auth.model';

export @Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
class RegisterComponent {
  registerForm: FormGroup;
  errorMessages: string[] = [];
  successMessage: string | null = null;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.registerForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.maxLength(100)]],
      email: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(100)]],
    });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      const registerDto: RegisterDTO = this.registerForm.value;
      this.authService.register(registerDto).subscribe({
        next: (response: ResponseDTO<AuthResponseDTO>) => {
          if (response.success) {
            this.successMessage = 'Registration successful!';
            this.errorMessages = [];
            setTimeout(() => this.router.navigate(['/']), 2000);
          } else {
            this.errorMessages = response.message.includes('Validation errors')
              ? response.message.split('; ').filter((msg: string) => msg.trim())
              : [response.message];
            this.successMessage = null;
          }
        },
        error: (err) => {
          this.errorMessages = ['An unexpected error occurred. Please try again.'];
          this.successMessage = null;
          console.error('Registration error:', err);
        },
      });
    } else {
      this.errorMessages = ['Please fill out the form correctly.'];
      this.successMessage = null;
    }
  }
}