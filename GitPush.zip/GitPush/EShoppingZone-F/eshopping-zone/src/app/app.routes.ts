import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { EmailVerificationComponent } from './components/email-verification/email-verification.component';
import { ProfileComponent } from './components/profile/profile.component';
import { LandingComponent } from './components/landing/landing.component';
import { ProductsComponent } from './components/products/products.component';
import { CartComponent } from './components/cart/cart.component';
import { OrdersComponent } from './components/orders/orders.component';
import { MerchantProductComponent } from './components/merchant-product/merchant-product.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { DeliveryDashboardComponent } from './components/delivery-dashboard/delivery-dashboard.component';
import { AddressComponent } from './components/address/address.component';
import { MerchantDashboardComponent } from './components/merchant-dashboard/merchant-dashboard.component';
import { ProductDetailComponent } from './components/product-detail/product-detail.component';
import { RoleGuard } from './guards/role.guard';

export const routes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'email-verification', component: EmailVerificationComponent },
  { path: 'profile', component: ProfileComponent, canActivate: [RoleGuard], data: { roles: ['Customer', 'Merchant', 'Admin', 'Delivery Agent'] } },
  { path: 'products', component: ProductsComponent },
  { path: 'cart', component: CartComponent, canActivate: [RoleGuard], data: { roles: ['Customer'] } },
  { path: 'orders', component: OrdersComponent, canActivate: [RoleGuard], data: { roles: ['Customer', 'Merchant'] } },
  { path: 'search', component: ProductsComponent },
  { path: 'merchant/dashboard', component: MerchantDashboardComponent, canActivate: [RoleGuard], data: { roles: ['Merchant'] } },
  { path: 'merchant/products', component: MerchantProductComponent, canActivate: [RoleGuard], data: { roles: ['Merchant'] } },
  { path: 'admin/dashboard', component: AdminDashboardComponent, canActivate: [RoleGuard], data: { roles: ['Admin'] } },
  { path: 'delivery/dashboard', component: DeliveryDashboardComponent, canActivate: [RoleGuard], data: { roles: ['Delivery Agent'] } },
  { path: 'addresses', component: AddressComponent, canActivate: [RoleGuard], data: { roles: ['Customer'] } },
  { path: 'product/:id', component: ProductDetailComponent },
];