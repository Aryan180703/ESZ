import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResponseDTO } from '../models/response.model';
import { CartRequest, CartResponse, UpdateCartItemRequest } from '../models/cart.model';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private baseUrl = 'http://localhost:5287/api/CartController';

  constructor(private http: HttpClient) {}

  addToCart(dto: CartRequest): Observable<ResponseDTO<CartResponse>> {
    return this.http.post<ResponseDTO<CartResponse>>(this.baseUrl, dto);
  }

  updateCartItem(itemId: number, dto: UpdateCartItemRequest): Observable<ResponseDTO<CartResponse>> {
    return this.http.put<ResponseDTO<CartResponse>>(`${this.baseUrl}/UpdateCart/${itemId}`, dto);
  }

  removeFromCart(itemId: number): Observable<ResponseDTO<CartResponse>> {
    return this.http.delete<ResponseDTO<CartResponse>>(`${this.baseUrl}/RemoveFromCart/${itemId}`);
  }

  getCart(): Observable<ResponseDTO<CartResponse>> {
    return this.http.get<ResponseDTO<CartResponse>>(`${this.baseUrl}/GetCart`);
  }

  clearCart(): Observable<ResponseDTO<CartResponse>> {
    return this.http.delete<ResponseDTO<CartResponse>>(`${this.baseUrl}/ClearCart`);
  }
}