import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResponseDTO } from '../models/response.model';
import { OrderRequest, OrderResponse, UpdateOrderStatusRequest } from '../models/order.model';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  private baseUrl = 'http://localhost:5287/api/OrderController';

  constructor(private http: HttpClient) {}

  placeOrder(dto: OrderRequest): Observable<ResponseDTO<OrderResponse>> {
    return this.http.post<ResponseDTO<OrderResponse>>(`${this.baseUrl}/PlaceOrder`, dto);
  }

  getOrder(orderId: number): Observable<ResponseDTO<OrderResponse>> {
    return this.http.get<ResponseDTO<OrderResponse>>(`${this.baseUrl}/GetOrder/${orderId}`);
  }

  getAllOrders(): Observable<ResponseDTO<OrderResponse[]>> {
    return this.http.get<ResponseDTO<OrderResponse[]>>(`${this.baseUrl}/GetAllOrders`);
  }

  updateOrderStatus(orderId: number, dto: UpdateOrderStatusRequest): Observable<ResponseDTO<OrderResponse>> {
    return this.http.put<ResponseDTO<OrderResponse>>(`${this.baseUrl}/UpdateOrderStatus/${orderId}`, dto);
  }

  cancelOrder(orderId: number): Observable<ResponseDTO<OrderResponse>> {
    return this.http.put<ResponseDTO<OrderResponse>>(`${this.baseUrl}/CancelOrder/${orderId}`, {});
  }
}