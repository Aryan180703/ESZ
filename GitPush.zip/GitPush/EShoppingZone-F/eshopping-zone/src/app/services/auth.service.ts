import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { RegisterDTO, LoginDTO, AuthResponseDTO, ConfirmEmailRequest, GenerateOtpRequest, ProfileResponse, UpdateProfileRequest, ProfileDetails } from '../models/auth.model';
import { ResponseDTO } from '../models/response.model';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl = 'http://localhost:5287/api/Auth';
  private currentUserSubject = new BehaviorSubject<AuthResponseDTO | null>(null);
  public currentUser = this.currentUserSubject.asObservable();
  private searchSubject = new BehaviorSubject<string>('');
  public searchQuery = this.searchSubject.asObservable();

  constructor(private http: HttpClient) {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    const id = localStorage.getItem('id');
    if (token && role && id) {
      this.currentUserSubject.next({ token, role, id: parseInt(id) });
    }
  }

  register(dto: RegisterDTO): Observable<ResponseDTO<AuthResponseDTO>> {
    return this.http.post<ResponseDTO<AuthResponseDTO>>(`${this.baseUrl}/Register`, dto).pipe(
      tap((response: ResponseDTO<AuthResponseDTO>) => {
        if (response.success) {
          this.setUser(response.data);
        }
      })
    );
  }

  login(dto: LoginDTO): Observable<ResponseDTO<AuthResponseDTO>> {
    return this.http.post<ResponseDTO<AuthResponseDTO>>(`${this.baseUrl}/Login`, dto).pipe(
      tap((response: ResponseDTO<AuthResponseDTO>) => {
        if (response.success && response.data) {
          this.setUser(response.data);
        }
      })
    );
  }

  generateOtp(dto: GenerateOtpRequest): Observable<ResponseDTO<string>> {
    return this.http.post<ResponseDTO<string>>(`${this.baseUrl}/GenerateOTP`, dto);
  }

  confirmEmail(dto: ConfirmEmailRequest): Observable<ResponseDTO<string>> {
    return this.http.post<ResponseDTO<string>>(`${this.baseUrl}/ConfirmEmail`, dto);
  }

  updateProfile(dto: UpdateProfileRequest): Observable<ResponseDTO<ProfileResponse>> {
    return this.http.put<ResponseDTO<ProfileResponse>>(`${this.baseUrl}/UpdateProfile`, dto);
  }

  viewProfile(): Observable<ResponseDTO<ProfileResponse>> {
    return this.http.get<ResponseDTO<ProfileResponse>>(`${this.baseUrl}/ViewProfile`);
  }

  getUserName(id: number): Observable<ProfileDetails> {
    return this.http.get<ProfileDetails>(`${this.baseUrl}/GetUserName/${id}`);
  }

  isEmailVerified(): Observable<boolean> {
    return this.viewProfile().pipe(
      map((response: ResponseDTO<ProfileResponse>) => response.success && response.data.emailConfirmed)
    );
  }

  search(query: string) {
    this.searchSubject.next(query);
  }

  setUser(user: AuthResponseDTO) {
    localStorage.setItem('token', user.token);
    localStorage.setItem('role', user.role);
    localStorage.setItem('id', user.id.toString());
    this.currentUserSubject.next(user);
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('id');
    this.currentUserSubject.next(null);
  }

  isLoggedIn(): boolean {
    return !!this.currentUserSubject.value;
  }

  getUserRole(): string | null {
    return this.currentUserSubject.value?.role || null;
  }

  getUserId(): number | null {
    return this.currentUserSubject.value?.id || null;
  }
}