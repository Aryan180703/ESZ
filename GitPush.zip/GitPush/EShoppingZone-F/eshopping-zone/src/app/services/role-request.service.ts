import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResponseDTO } from '../models/response.model';

interface UserRoleRequest {
  id: number;
  userId: number;
  requestedRole: string;
  status: string;
  requestedDate: string;
  approvedBy?: number;
  approvedDate?: string;
  userName?: string;
  createdAt?: string;
}

export @Injectable({
  providedIn: 'root',
})
class RoleRequestService {
  private baseUrl = 'http://localhost:5287/api/RoleRequest';

  constructor(private http: HttpClient) {}

  submitRoleRequest(requestedRole: string): Observable<ResponseDTO<string>> {
    return this.http.post<ResponseDTO<string>>(`${this.baseUrl}/RequestRole`, `"${requestedRole}"`, {
      headers: { 'Content-Type': 'application/json' },
    });
  }

  checkRoleRequestStatus(requestedRole: string): Observable<ResponseDTO<string>> {
    return this.http.get<ResponseDTO<string>>(`${this.baseUrl}/Status`, { params: { requestedRole } });
  }

  getPendingRequests(): Observable<ResponseDTO<UserRoleRequest[]>> {
    return this.http.get<ResponseDTO<UserRoleRequest[]>>(`${this.baseUrl}/PendingRequests`);
  }
}