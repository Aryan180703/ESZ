import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ResponseDTO } from '../models/response.model';
import { ProductRequest, ProductResponse, UpdateProductRequest } from '../models/product.model';
import { RatingResponse, RatingRequest } from '../models/rating.model';

export @Injectable({
  providedIn: 'root',
})
class ProductService {
  private baseUrl = 'http://localhost:5287/api/ProductController';
  private ratingUrl = 'http://localhost:5287/api/Rating';

  constructor(private http: HttpClient) {}

  addProduct(dto: ProductRequest): Observable<ResponseDTO<ProductResponse>> {
    return this.http.post<ResponseDTO<ProductResponse>>(this.baseUrl, dto);
  }

  getMerchantProducts(): Observable<ResponseDTO<ProductResponse[]>> {
    return this.http.get<ResponseDTO<ProductResponse[]>>(`${this.baseUrl}/MerchantGetProdut`);
  }

  getAllProducts(): Observable<ResponseDTO<ProductResponse[]>> {
    return this.http.get<ResponseDTO<ProductResponse[]>>(`${this.baseUrl}/GetAllProducts`);
  }

  getProduct(productId: number): Observable<ResponseDTO<ProductResponse>> {
    return this.http.get<ResponseDTO<ProductResponse>>(`${this.baseUrl}/GetProduct/${productId}`);
  }

  updateProduct(productId: number, dto: UpdateProductRequest): Observable<ResponseDTO<ProductResponse>> {
    return this.http.put<ResponseDTO<ProductResponse>>(`${this.baseUrl}/UpdateProduct/${productId}`, dto);
  }

  deleteProduct(productId: number): Observable<ResponseDTO<ProductResponse>> {
    return this.http.delete<ResponseDTO<ProductResponse>>(`${this.baseUrl}/DeleteProduct/${productId}`);
  }

  getCategories(): Observable<string[]> {
    return this.http.get<ResponseDTO<ProductResponse[]>>(`${this.baseUrl}/GetAllProducts`).pipe(
      map((response: ResponseDTO<ProductResponse[]>) => {
        return [...new Set(response.data.map(product => product.category).filter(category => category))];
      })
    );
  }

  getRatingsByProduct(productId: number): Observable<ResponseDTO<RatingResponse[]>> {
    return this.http.get<ResponseDTO<RatingResponse[]>>(`${this.ratingUrl}/product/${productId}`);
  }

  addRating(dto: RatingRequest): Observable<ResponseDTO<RatingResponse>> {
    return this.http.post<ResponseDTO<RatingResponse>>(this.ratingUrl, dto);
  }
}