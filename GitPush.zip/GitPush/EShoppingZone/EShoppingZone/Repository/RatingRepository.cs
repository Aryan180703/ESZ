using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.Data;
using EShoppingZone.Interfaces;
using EShoppingZone.Models;
using Microsoft.EntityFrameworkCore;

namespace EShoppingZone.Repository
{
    public class RatingRepository : IRatingRepository
    {
        private readonly EShoppingZoneDBContext _context;

        public RatingRepository(EShoppingZoneDBContext context)
        {
            _context = context;
        }

        public async Task<Rating> GetRatingAsync(int productId, int userProfileId)
        {
            return await _context.Ratings
                .FirstOrDefaultAsync(r => r.ProductId == productId && r.UserProfileId == userProfileId);
        }

        public async Task CreateRatingAsync(Rating rating)
        {
            await _context.Ratings.AddAsync(rating);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Rating>> GetRatingsByProductAsync(int productId)
        {
            var exist = await _context.Products.FirstOrDefaultAsync(a => a.Id == productId);
            if(exist == null){
                return null;
            }
            return await _context.Ratings
                .Where(r => r.ProductId == productId)
                .ToListAsync();
        }

        public async Task<Product> GetProductAsync(int productId)
        {
            return await _context.Products
                .Include(p => p.Ratings)
                .FirstOrDefaultAsync(p => p.Id == productId);
        }

        public async Task UpdateProductAsync(Product product)
        {
            _context.Products.Update(product);
            await _context.SaveChangesAsync();
        }
    }
}