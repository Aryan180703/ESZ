using System;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace EShoppingZone.Middlewares
{
    public class ExceptionHandlerMiddleware
    {
        private readonly RequestDelegate _next; private readonly ILogger _logger;

        public ExceptionHandlerMiddleware(RequestDelegate next, ILogger<ExceptionHandlerMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unhandled exception: {Message} at {Path}", ex.Message, context.Request.Path);
                await HandleExceptionAsync(context, ex);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            HttpStatusCode statusCode;
            string message;

            try
            {
                switch (exception)
                {
                    case ObjectDisposedException ode:
                        statusCode = HttpStatusCode.InternalServerError;
                        message = "Stream access error: " + ode.Message;
                        break;
                    case ArgumentNullException ane:
                        statusCode = HttpStatusCode.BadRequest;
                        message = ane.Message ?? "A required value was null.";
                        break;
                    case KeyNotFoundException knfe:
                        statusCode = HttpStatusCode.NotFound;
                        message = knfe.Message ?? "Resource not found.";
                        break;
                    case UnauthorizedAccessException uae:
                        statusCode = HttpStatusCode.Unauthorized;
                        message = uae.Message ?? "Unauthorized access.";
                        break;
                    case InvalidOperationException ioe:
                        statusCode = HttpStatusCode.BadRequest;
                        message = ioe.Message ?? "Invalid operation.";
                        break;
                    default:
                        statusCode = HttpStatusCode.InternalServerError;
                        message = "An unexpected error occurred.";
                        _logger.LogError(exception, "Detailed error: {Message}", exception.ToString());
                        break;
                }

                var response = new ResponseDTO<object>
                {
                    Success = false,
                    Message = message,
                    Data = null
                };

                context.Response.ContentType = "application/json";
                context.Response.StatusCode = (int)statusCode;

                // Ensure response body is writable
                if (!context.Response.HasStarted)
                {
                    var result = JsonSerializer.Serialize(response, new JsonSerializerOptions
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                        WriteIndented = true
                    });
                    await context.Response.WriteAsync(result);
                }
                else
                {
                    _logger.LogWarning("Response already started, cannot write error response.");
                }
            }
            catch (Exception serializationEx)
            {
                _logger.LogCritical(serializationEx, "Serialization error in exception handling: {Message}", serializationEx.Message);
                if (!context.Response.HasStarted)
                {
                    context.Response.ContentType = "application/json";
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    await context.Response.WriteAsync("{\"success\":false,\"message\":\"Critical error in exception handling.\"}");
                }
            }
        }
    }
}
