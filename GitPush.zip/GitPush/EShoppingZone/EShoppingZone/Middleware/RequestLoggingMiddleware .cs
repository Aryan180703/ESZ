using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace EShoppingZone.Middlewares
{
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next; private readonly ILogger _logger;

        public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                // Log Request
                var request = await FormatRequest(context.Request);
                _logger.LogInformation("Incoming Request: {Method} {Path} {RequestBody}",
                    context.Request.Method, context.Request.Path, request);

                // Capture Response
                var originalBodyStream = context.Response.Body;
                var responseBody = new MemoryStream(); // No 'using' to avoid premature dispose
                context.Response.Body = responseBody;

                try
                {
                    // Call next middleware
                    await _next(context);

                    // Log Response
                    var response = await FormatResponse(context.Response);
                    _logger.LogInformation("Outgoing Response: {StatusCode} {ResponseBody}",
                        context.Response.StatusCode, response);

                    // Copy response to original stream
                    if (responseBody.CanSeek)
                    {
                        responseBody.Seek(0, SeekOrigin.Begin);
                        await responseBody.CopyToAsync(originalBodyStream);
                    }
                }
                finally
                {
                    // Restore original body and dispose responseBody
                    context.Response.Body = originalBodyStream;
                    responseBody.Dispose(); // Explicitly dispose
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in RequestLoggingMiddleware: {Message}", ex.Message);
                throw; // Let ExceptionMiddleware handle
            }
        }

        private async Task<string> FormatRequest(HttpRequest request)
        {
            try
            {
                if (!request.Body.CanRead)
                {
                    return $"{{ Query: {request.QueryString}, Body: <empty> }}";
                }

                request.EnableBuffering();
                using var reader = new StreamReader(
                    request.Body,
                    encoding: Encoding.UTF8,
                    detectEncodingFromByteOrderMarks: false,
                    leaveOpen: true);
                var body = await reader.ReadToEndAsync();
                request.Body.Seek(0, SeekOrigin.Begin);
                return $"{{ Query: {request.QueryString}, Body: {body} }}";
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to read request body: {Message}", ex.Message);
                return $"{{ Query: {request.QueryString}, Body: <unreadable> }}";
            }
        }

        private async Task<string> FormatResponse(HttpResponse response)
        {
            try
            {
                if (!response.Body.CanRead || !response.Body.CanSeek)
                {
                    return "<empty>";
                }

                response.Body.Seek(0, SeekOrigin.Begin);
                using var reader = new StreamReader(response.Body, leaveOpen: true);
                var body = await reader.ReadToEndAsync();
                response.Body.Seek(0, SeekOrigin.Begin);
                return body.Length > 0 ? body : "{}";
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to read response body: {Message}", ex.Message);
                return "<unreadable>";
            }
        }
    }
}