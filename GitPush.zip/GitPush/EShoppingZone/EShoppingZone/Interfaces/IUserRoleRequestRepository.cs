using System.Collections.Generic;
using System.Threading.Tasks;
using EShoppingZone.Models;
using EShoppingZone.Data;

namespace EShoppingZone.Interfaces
{
    public interface IUserRoleRequestRepository
    {
        Task<UserRoleRequest> GetRequestByUserIdAndRoleAsync(int userId, string requestedRole);
        Task AddRequestAsync(UserRoleRequest request);
        Task<UserRoleRequest> GetRequestByIdAsync(int requestId);
        Task UpdateRequestAsync(UserRoleRequest request);
        Task<List<UserRoleRequest>> GetPendingRequestsAsync();
    }
}