using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.Models;
using EShoppingZone.Data;

namespace EShoppingZone.Interfaces
{
    public interface IUserRoleRequestService
    {
        Task<ResponseDTO<string>> SubmitRoleRequestAsync(int userId, string requestedRole);
        Task<ResponseDTO<string>> GetRequestStatusAsync(int userId, string requestedRole);
        Task<ResponseDTO<UserRoleRequest[]>> GetPendingRequestsAsync();
        Task<ResponseDTO<string>> ApproveRequestAsync(int requestId, int adminId, bool isApproved);
    }
}