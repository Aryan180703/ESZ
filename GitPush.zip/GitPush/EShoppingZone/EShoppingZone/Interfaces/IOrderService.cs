using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.OrderDTOs;

namespace EShoppingZone.Interfaces
{
    public interface IOrderService
    {
        Task<ResponseDTO<OrderResponse>> PlaceOrderAsync(int profileId, OrderRequest orderRequest);
        Task<ResponseDTO<OrderResponse>> GetOrderAsync(int profileId, int orderId);
        Task<ResponseDTO<List<OrderResponse>>> GetAllOrdersAsync(int profileId);
        Task<ResponseDTO<OrderResponse>> UpdateOrderStatusAsync(int profileId, int orderId, UpdateOrderStatusRequest updateRequest);
        Task<ResponseDTO<OrderResponse>> CancelOrderAsync(int profileId, int orderId);
        
    }
}