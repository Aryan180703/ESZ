using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EShoppingZone.DTOs.RatingDTOs
{
     public class RatingRequest
    {
        public int ProductId { get; set; }
        public int StarRating { get; set; }
        public string? Review { get; set; }
    }
}