// namespace EShoppingZone.Models
// {
//     public class UserRoleRequest
//     {
//         public int Id { get; set; }
//         public int UserId { get; set; }
//         public string RequestedRole { get; set; }
//         public string Status { get; set; }
//         public DateTime RequestedDate { get; set; }
//         public int? ApprovedBy { get; set; }
//         public DateTime? ApprovedDate { get; set; }
//     }
// }