using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.AddressDTOs;
using EShoppingZone.DTOs.CartDTOs;
using EShoppingZone.DTOs.OrderDTOs;
using EShoppingZone.DTOs.ProductDTOs;
using EShoppingZone.DTOs.RatingDTOs;
using EShoppingZone.Models;

namespace EShoppingZone.Services
{
    public class AutoMapperService : Profile
    {
        public AutoMapperService()
        {
            CreateMap<AddressRequest, Address>();
            CreateMap<Address, AddressResponse>();
            CreateMap<Product, ProductResponse>();
            CreateMap<ProductRequest, Product>();
            CreateMap<Cart, CartResponse>();
            CreateMap<CartItem, CartItemResponse>();
            CreateMap<CartRequest, CartItem>();
            CreateMap<UserProfile, ProfileResponse>()
                .ForMember(dest => dest.EmailConfirmed, opt => opt.MapFrom(src => src.EmailConfirmed));
            CreateMap<Order, OrderResponse>();
            CreateMap<OrderItem, OrderItemResponse>();
            CreateMap<OrderRequest, Order>();
            CreateMap<Rating, RatingResponse>();
            CreateMap<RatingResponse, Rating>();
        }
    }
}