using System;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.Data;
using EShoppingZone.DTOs;
using EShoppingZone.Models;
using EShoppingZone.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace EShoppingZone.Services
{
    public class UserRoleRequestService : IUserRoleRequestService
    {
        private readonly EShoppingZoneDBContext _context;
        private readonly IUserRoleRequestRepository _repository;
        private readonly UserManager<UserProfile> _userManager;

        public UserRoleRequestService(EShoppingZoneDBContext context, IUserRoleRequestRepository repository, UserManager<UserProfile> userManager)
        {
            _context = context;
            _repository = repository;
            _userManager = userManager;
        }

        public async Task<ResponseDTO<string>> SubmitRoleRequestAsync(int userId, string requestedRole)
        {
            try
            {
                var user = await _context.Users.FindAsync(userId);
                if (user == null)
                {
                    return new ResponseDTO<string> { Success = false, Message = "User not found", Data = null };
                }

                var existingRequest = await _repository.GetRequestByUserIdAndRoleAsync(userId, requestedRole);
                if (existingRequest != null && existingRequest.Status == "Pending")
                {
                    return new ResponseDTO<string> { Success = false, Message = "You already have a pending request for this role", Data = null };
                }

                var roleRequest = new UserRoleRequest
                {
                    UserId = userId,
                    RequestedRole = requestedRole,
                    Status = "Pending",
                    RequestedDate = DateTime.Now
                };

                await _repository.AddRequestAsync(roleRequest);

                return new ResponseDTO<string>
                {
                    Success = true,
                    Message = "Role request submitted successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new ResponseDTO<string> { Success = false, Message = ex.Message, Data = null };
            }
        }

        public async Task<ResponseDTO<string>> GetRequestStatusAsync(int userId, string requestedRole)
        {
            try
            {
                var request = await _repository.GetRequestByUserIdAndRoleAsync(userId, requestedRole);

                if (request == null)
                {
                    return new ResponseDTO<string> { Success = false, Message = "No pending request found", Data = null };
                }

                return new ResponseDTO<string>
                {
                    Success = true,
                    Message = $"Request status: {request.Status}",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new ResponseDTO<string> { Success = false, Message = ex.Message, Data = null };
            }
        }

        public async Task<ResponseDTO<UserRoleRequest[]>> GetPendingRequestsAsync()
        {
            try
            {
                var requests = await _repository.GetPendingRequestsAsync();

                return new ResponseDTO<UserRoleRequest[]>
                {
                    Success = true,
                    Message = "Pending role requests retrieved successfully",
                    Data = requests.ToArray()
                };
            }
            catch (Exception ex)
            {
                return new ResponseDTO<UserRoleRequest[]>
                {
                    Success = false,
                    Message = ex.Message,
                    Data = null
                };
            }
        }

        public async Task<ResponseDTO<string>> ApproveRequestAsync(int requestId, int adminId, bool isApproved)
        {
            try
            {
                var request = await _repository.GetRequestByIdAsync(requestId);
                if (request == null)
                {
                    return new ResponseDTO<string> { Success = false, Message = "Request not found", Data = null };
                }

                if (request.Status != "Pending")
                {
                    return new ResponseDTO<string> { Success = false, Message = "Request is not pending", Data = null };
                }

                request.Status = isApproved ? "Approved" : "Rejected";
                request.ApprovedBy = adminId;
                request.ApprovedDate = DateTime.Now;

                if (isApproved)
                {
                    var user = await _userManager.FindByIdAsync(request.UserId.ToString());
                    if (user != null)
                    {
                        // Remove existing roles and add the new role
                        var currentRoles = await _userManager.GetRolesAsync(user);
                        await _userManager.RemoveFromRolesAsync(user, currentRoles);
                        await _userManager.AddToRoleAsync(user, request.RequestedRole);
                    }
                }

                await _repository.UpdateRequestAsync(request);

                return new ResponseDTO<string>
                {
                    Success = true,
                    Message = isApproved ? "Request approved successfully" : "Request rejected successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new ResponseDTO<string> { Success = false, Message = ex.Message, Data = null };
            }
        }
    }
}