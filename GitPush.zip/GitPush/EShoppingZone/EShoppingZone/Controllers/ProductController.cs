using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.ProductDTOs;
using EShoppingZone.Interfaces;
using EShoppingZone.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EShoppingZone.Controllers
{
    [ApiController]
    [Route("api/ProductController")]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductController(IProductService service)
        {
            _service = service;
        }
        [HttpPost]
        [Authorize(Roles = "Merchant")]
        public async Task<IActionResult> AddProduct([FromBody] ProductRequest productRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));   
            }
            var profileId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.AddProductAsync(profileId, productRequest);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet("MerchantGetProdut")]
        [Authorize(Roles = "Merchant")]
        public async Task<IActionResult> GetMerchantProducts()
        {
            var profileId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.GetMerchantsProductAsync(profileId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet("GetAllProducts")]
        public async Task<IActionResult> GetAllProducts()
        {
            var response = await _service.GetAllProductsAsync();
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }


        [HttpGet("GetProduct/{productId}")]
        public async Task<IActionResult> GetProduct(int productId)
        {
            var response = await _service.GetProductAsync(productId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [Authorize(Roles = "Merchant")]
        [HttpPut("UpdateProduct/{productId}")]
        public async Task<IActionResult> UpdateProduct(int productId, [FromBody] UpdateProductRequest updateProductRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));   
            }
            var profileId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.UpdateProductAsync(profileId, productId, updateProductRequest);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [Authorize(Roles = "Merchant")]
        [HttpDelete("DeleteProduct/{productId}")]
        public async Task<IActionResult> DeleteProduct(int productId)
        {
            var profileId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.DeleteProductAsync(profileId, productId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }
    }
}