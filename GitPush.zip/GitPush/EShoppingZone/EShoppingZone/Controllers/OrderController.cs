using System;
using System.Security.Claims;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.OrderDTOs;
using EShoppingZone.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EShoppingZone.Controllers
{
    [Route("api/OrderController")]
    [ApiController]
    [Authorize]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _service;

        public OrderController(IOrderService service)
        {
            _service = service;
        }

        [HttpPost("PLaceOrder")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> PlaceOrder([FromBody] OrderRequest orderRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));   
            }
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.PlaceOrderAsync(profileId, orderRequest);
            if (response.Success)
            {
                return Ok(response);
            }
                return BadRequest(response);
            
        }

        [HttpGet("GetOrder/{orderId}")]
        [Authorize(Roles = "Customer,Merchant")]
        public async Task<IActionResult> GetOrder(int orderId)
        {
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.GetOrderAsync(profileId, orderId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet("GetAllOrders")]
        [Authorize(Roles = "Customer,Merchant")]
        public async Task<IActionResult> GetAllOrders()
        {
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.GetAllOrdersAsync(profileId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpPut("UpdateOrderStatus/{orderId}")]
        [Authorize(Roles = "Delivery Agent")]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, [FromBody] UpdateOrderStatusRequest updateRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));   
            }
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.UpdateOrderStatusAsync(profileId, orderId, updateRequest);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpPut("CancelOrder/{orderId}")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> CancelOrder(int orderId)
        {
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.CancelOrderAsync(profileId, orderId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }
        
    }
}