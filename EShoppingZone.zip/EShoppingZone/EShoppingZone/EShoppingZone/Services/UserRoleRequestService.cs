using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.Data;
using EShoppingZone.DTOs;
using EShoppingZone.Interfaces;
using EShoppingZone.Models;
using Microsoft.AspNetCore.Identity;

namespace EShoppingZone.Services
{
    public class UserRoleRequestService : IUserRoleRequestService
    {
        private readonly IUserRoleRequestRepository _repository;
        private readonly UserManager<UserProfile> _userManager;
        private readonly IEmailService _emailService;

        public UserRoleRequestService(IUserRoleRequestRepository repository, UserManager<UserProfile> userManager, IEmailService emailService)
        {
            _repository = repository;
            _userManager = userManager;
            _emailService = emailService;
        }

        public async Task<ResponseDTO<string>> SubmitRoleRequestAsync(int userId, string requestedRole)
        {
            var existingRequest = await _repository.GetRequestByUserIdAsync(userId, requestedRole);
            if (existingRequest != null && existingRequest.Status == "Pending")
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "A request for this role is already pending."
                };
            }

            var user = await _userManager.FindByIdAsync(userId.ToString());
            if (user == null)
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "User not found."
                };
            }

            var request = new UserRoleRequest
            {
                UserId = userId,
                RequestedRole = requestedRole,
                Status = "Pending"
            };

            await _repository.CreateRequestAsync(request);

            string MailBody = $"<p>Dear {user.FullName},</p><p>Your application to become a {requestedRole} has been received. We will review it soon.</p>";
            string MailSubject = "Role Change Request Submitted";
            await _emailService.SendEmailAsync(user.Email, MailBody, MailSubject);

            return new ResponseDTO<string>
            {
                Success = true,
                Message = "Your application is being reviewed, stay tuned."
            };
        }

        public async Task<ResponseDTO<string>> GetRequestStatusAsync(int userId, string requestedRole)
        {
            var request = await _repository.GetRequestByUserIdAsync(userId, requestedRole);
            if (request == null)
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "No request found for this role."
                };
            }

            return new ResponseDTO<string>
            {
                Success = true,
                Message = $"Request Status: {request.Status}"
            };
        }

        public async Task<ResponseDTO<string>> ApproveRequestAsync(int requestId, int adminId, bool isApproved)
        {
            var request = await _repository.GetRequestByIdAsync(requestId);
            if (request == null)
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "Request not found."
                };
            }

            var user = await _userManager.FindByIdAsync(request.UserId.ToString());
            if (user == null)
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "User not found."
                };
            }

            request.Status = isApproved ? "Approved" : "Rejected";
            request.ApprovedBy = adminId;
            request.ApprovedDate = DateTime.UtcNow;
            await _repository.UpdateRequestAsync(request);

            if (isApproved)
            {
                await _userManager.AddToRoleAsync(user, request.RequestedRole);
                string MailBody = $"<p>Dear {user.FullName},</p><p>Congratulations! Your application to become a {request.RequestedRole} is accepted.</p>";
                string MailSubject = "Role Change Request Approved";
                await _emailService.SendEmailAsync(user.Email, MailBody, MailSubject);
            }
            else
            {
                string MailBody = $"<p>Dear {user.FullName},</p><p>Currently we are looking to expand our team... Your application to become a {request.RequestedRole} is rejected.</p>";
                string MailSubject = "Role Change Request Rejected";
                await _emailService.SendEmailAsync(user.Email, MailBody, MailSubject);
            }

            return new ResponseDTO<string>
            {
                Success = true,
                Message = $"Request {request.Status}."
            };
        }
    }
}