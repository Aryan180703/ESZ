using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using EShoppingZone.Data;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.OrderDTOs;
using EShoppingZone.Interfaces;
using EShoppingZone.Models;
using Microsoft.EntityFrameworkCore;

namespace EShoppingZone.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repository;
        private readonly IMapper _mapper;
        private readonly EShoppingZoneDBContext _context;


        public OrderService(IOrderRepository repository, IMapper mapper, EShoppingZoneDBContext context)
        {
            _repository = repository;
            _mapper = mapper;
            _context = context;
        }

        public async Task<ResponseDTO<OrderResponse>> PlaceOrderAsync(int profileId, OrderRequest orderRequest)
        {
            var cart = await _repository.GetCartAsync(orderRequest.CartId);
            if (cart == null || cart.UserProfileId != profileId || !cart.Items.Any())
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Invalid or empty cart"
                };
            }

            var address = await _repository.GetAddressAsync(orderRequest.AddressId);
            if (address == null || address.UserProfileId != profileId)
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Invalid address"
                };
            }

            foreach (var item in cart.Items)
            {
                var product = await _repository.GetProductAsync(item.ProductId);
                if (product == null || product.Stock < item.Quantity)
                {
                    return new ResponseDTO<OrderResponse>
                    {
                        Success = false,
                        Message = $"Insufficient stock for product: {item.ProductName}"
                    };
                }
            }

            var order = new Order
            {
                CustomerId = profileId,
                AddressId = orderRequest.AddressId,
                TotalPrice = cart.TotalPrice,
                Status = "Placed",
                OrderDate = DateTime.UtcNow
            };

            foreach (var item in cart.Items)
            {
                var product = await _repository.GetProductAsync(item.ProductId);
                if (product == null)
                {
                    return new ResponseDTO<OrderResponse>
                    {
                        Success = false,
                        Message = $"Product {item.ProductId} not found"
                    };
                }
                order.Items.Add(new OrderItem
                {
                    ProductId = item.ProductId,
                    ProductName = item.ProductName,
                    Price = item.Price,
                    Quantity = item.Quantity
                });
            }

            foreach (var item in cart.Items)
            {
                var product = await _context.Products.FindAsync(item.ProductId);
                product.Stock -= item.Quantity;
                _context.Products.Update(product);
            }

            var createdOrder = await _repository.CreateOrderAsync(order);
            await _repository.ClearCartAsync(cart);

            var response = await GetOrderResponseAsync(createdOrder);
            return new ResponseDTO<OrderResponse>
            {
                Success = true,
                Message = "Order placed successfully",
                Data = response
            };
        }

        public async Task<ResponseDTO<OrderResponse>> GetOrderAsync(int profileId, int orderId)
        {
            var order = await _repository.GetOrderAsync(orderId);
            if (order == null || (order.CustomerId != profileId && !await _repository.IsMerchantAsync(profileId)))
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Order not found or unauthorized"
                };
            }

            var response = await GetOrderResponseAsync(order);
            return new ResponseDTO<OrderResponse>
            {
                Success = true,
                Message = "Order retrieved",
                Data = response
            };
        }

        public async Task<ResponseDTO<List<OrderResponse>>> GetAllOrdersAsync(int profileId)
        {
            var isMerchant = await _repository.IsMerchantAsync(profileId);
            var orders = await _repository.GetAllOrdersAsync(profileId, isMerchant);

            if (!orders.Any())
            {
                return new ResponseDTO<List<OrderResponse>>
                {
                    Success = false,
                    Message = "No orders found"
                };
            }

            var response = new List<OrderResponse>();
            foreach (var order in orders)
            {
                response.Add(await GetOrderResponseAsync(order));
            }

            return new ResponseDTO<List<OrderResponse>>
            {
                Success = true,
                Message = "Orders retrieved",
                Data = response
            };
        }

        public async Task<ResponseDTO<OrderResponse>> UpdateOrderStatusAsync(int profileId, int orderId, UpdateOrderStatusRequest updateRequest)
        {
            var isDeliveryAgent = await _repository.IsDeliveryAgentAsync(profileId);
            if (!isDeliveryAgent)
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Unauthorized"
                };
            }

            var order = await _repository.GetOrderAsync(orderId);
            if (order == null)
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Order not found"
                };
            }

            var validStatuses = new[] { "Placed", "Shipped", "Delivered", "Cancelled" };
            if (!validStatuses.Contains(updateRequest.Status))
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Invalid status"
                };
            }

            order.Status = updateRequest.Status;
            await _repository.UpdateOrderAsync(order);

            var response = await GetOrderResponseAsync(order);
            return new ResponseDTO<OrderResponse>
            {
                Success = true,
                Message = "Order status updated",
                Data = response
            };
        }

        public async Task<ResponseDTO<OrderResponse>> CancelOrderAsync(int profileId, int orderId)
        {
            var order = await _repository.GetOrderAsync(orderId);
            if (order == null || order.CustomerId != profileId)
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Order not found or unauthorized"
                };
            }

            if (order.Status != "Placed")
            {
                return new ResponseDTO<OrderResponse>
                {
                    Success = false,
                    Message = "Cannot cancel order, already processed"
                };
            }

            order.Status = "Cancelled";
            await _repository.UpdateOrderAsync(order);

            foreach (var item in order.Items)
            {
                var product = await _context.Products.FindAsync(item.ProductId);
                if(product==null){
                    return new ResponseDTO<OrderResponse>{Success=false,Message="null"};
                }
                product.Stock += item.Quantity;
                _context.Products.Update(product);
                await _context.SaveChangesAsync();
            }

            var response = await GetOrderResponseAsync(order);
            return new ResponseDTO<OrderResponse>
            {
                Success = true,
                Message = "Order cancelled",
                Data = response
            };
        }

        private async Task<OrderResponse> GetOrderResponseAsync(Order order)
        {
            var response = _mapper.Map<OrderResponse>(order);
            response.Items = order.Items.Select(i => _mapper.Map<OrderItemResponse>(i)).ToList();
            return response;
        }
    }
}