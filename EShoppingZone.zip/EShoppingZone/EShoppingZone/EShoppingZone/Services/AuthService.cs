using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using EShoppingZone.Data;
using EShoppingZone.DTOs;
using EShoppingZone.Interfaces;
using EShoppingZone.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace EShoppingZone.Services
{
    public class AuthService : IAuthService
    {
        private readonly UserManager<UserProfile> _userManager;
        private readonly SignInManager<UserProfile> _signInManager;
        private readonly EShoppingZoneDBContext _context;
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        private readonly IEmailService _emailService;

        public AuthService(UserManager<UserProfile> userManager, SignInManager<UserProfile> signInManager, EShoppingZoneDBContext context, IConfiguration configuration, IMapper mapper, IEmailService emailService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
            _configuration = configuration;
            _mapper = mapper;
            _emailService = emailService;
        }

        public async Task<AuthResponseDTO> RegisterAsync(RegisterDTO registerDto)
        {
            var user = new UserProfile
            {
                UserName = registerDto.Email,
                Email = registerDto.Email,
                FullName = registerDto.FullName,
                MobileNumber = registerDto.MobileNumber,
            };

            var result = await _userManager.CreateAsync(user, registerDto.Password);
            if (!result.Succeeded)
                throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));

            string MailSubject = "Welcome to EShoppingZone!";
            string MailBody = $"<p>Dear {user.FullName},</p>" +
               "<p>Welcome to <strong>Eshopping Zone</strong>! 🎉</p>" +
               "<p>We are thrilled to have you join our shopping community. Explore amazing products and great deals!</p>" +
               "<p>Happy Shopping! 🛒</p>" +
               "<p>Best Regards,<br/>The Eshopping Zone Team</p>";
            await _emailService.SendEmailAsync(user.Email, MailBody, MailSubject);
            await _userManager.AddToRoleAsync(user, "Customer");
            var token = await GenerateJwtToken(user, "Customer");
            return new AuthResponseDTO { Token = token, Role = "Customer" };
        }

        public async Task<AuthResponseDTO> LoginAsync(LoginDTO loginDto)
        {
            var user = await _userManager.FindByEmailAsync(loginDto.Email);
            if (user == null)
            {
                return null;
            }    
            var result = await _signInManager.PasswordSignInAsync(user, loginDto.Password, false, false);
            if (!result.Succeeded)
            {
                return null;
            }
            var roles = await _userManager.GetRolesAsync(user);
            var role = roles.FirstOrDefault() ?? "Customer";
            var token = await GenerateJwtToken(user, role); 
            return new AuthResponseDTO
            {
                Token = token,
                Role = role,
                Id = user.Id
            };
        }

        public async Task<ResponseDTO<ProfileResponse>> UpdateProfileAsync(int profileId, UpdateProfileRequest updateProfileRequest)
        {
            var user = await _userManager.FindByIdAsync(profileId.ToString());
            user.FullName = updateProfileRequest.FullName;
            user.MobileNumber = updateProfileRequest.MobileNumber;
            user.About = updateProfileRequest.About;
            user.Gender = updateProfileRequest.Gender;
            user.Image = updateProfileRequest.Image;
            user.DateOfBirth = updateProfileRequest.DateOfBirth;
            await _context.SaveChangesAsync();
            var response = new ProfileResponse
            {
                FullName = user.FullName,
                Email = user.Email,
                About = user.About,
                Image = user.Image,
                Gender = user.Gender,
                DateOfBirth = user.DateOfBirth,
                MobileNumber = user.MobileNumber
            };
            return new ResponseDTO<ProfileResponse>
            {
                Success = true,
                Message = "Profile Updated",
                Data = response
            };
        }

        public async Task<ResponseDTO<ProfileResponse>> ViewProfile(int profileId)
        {
            var user = await _context.Profiles.FirstOrDefaultAsync(a => a.Id == profileId);
            var response = new ProfileResponse
            {
                FullName = user.FullName,
                Email = user.Email,
                About = user.About,
                Image = user.Image,
                Gender = user.Gender,
                DateOfBirth = user.DateOfBirth,
                MobileNumber = user.MobileNumber
            };
            return new ResponseDTO<ProfileResponse>
            {
                Success = true,
                Message = "Profile Retrieved",
                Data = response
            };
        }

        private async Task<string> GenerateJwtToken(UserProfile user, string role)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(ClaimTypes.Role, role),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(59),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<ResponseDTO<string>> GenerateOtpAsync(string email)
        {
            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "User not found."
                };
            }

            var otp = new Random().Next(100000, 999999).ToString();
            InMemoryOtpStore.StoreOtp(email, otp, DateTime.UtcNow.AddMinutes(10));
            string MailBody = $"Your OTP for Email Verification is : {otp}";
            string MailSubject = "Email Verification";
            await _emailService.SendEmailAsync(user.Email, MailBody, MailSubject);
            return new ResponseDTO<string>
            {
                Success = true,
                Message = "OTP generated and sent to your email.",
                Data = otp
            };
        }

        public async Task<ResponseDTO<string>> ConfirmEmailAsync(string email, string otp)
        {
            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "User not found."
                };
            }

            var otpData = InMemoryOtpStore.GetOtp(email);
            if (otpData == null || otpData.Value.Otp != otp || otpData.Value.ExpiresAt < DateTime.UtcNow)
            {
                return new ResponseDTO<string>
                {
                    Success = false,
                    Message = "Invalid or expired OTP."
                };
            }

            user.EmailConfirmed = true;
            await _userManager.UpdateAsync(user);
            InMemoryOtpStore.RemoveOtp(email);

            return new ResponseDTO<string>
            {
                Success = true,
                Message = "Email confirmed successfully."
            };
        }

        public async Task<ProfileDetails> GetUserName(int id)
        {
            var user = await _context.Profiles.FirstOrDefaultAsync(a => a.Id == id);
            if (user == null)
            {
                return null;
            }
            var res = new ProfileDetails
            {
                Id = user.Id,
                FullName = user.FullName,
                Email = user.Email
            };
            return res;
        }
    }
}