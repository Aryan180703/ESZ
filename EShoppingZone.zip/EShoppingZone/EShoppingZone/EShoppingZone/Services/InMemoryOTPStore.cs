using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EShoppingZone.Services
{
    public static class InMemoryOtpStore
    {
        private static readonly ConcurrentDictionary<string, (string Otp, DateTime ExpiresAt)> _otpStore = new();

        public static void StoreOtp(string email, string otp, DateTime expiresAt)
        {
            _otpStore[email] = (otp, expiresAt);
        }

        public static (string Otp, DateTime ExpiresAt)? GetOtp(string email)
        {
            return _otpStore.TryGetValue(email, out var otpData) ? otpData : null;
        }

        public static void RemoveOtp(string email)
        {
            _otpStore.TryRemove(email, out _);
        }
    }
}