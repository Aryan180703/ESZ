using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.RatingDTOs;
using EShoppingZone.Interfaces;
using EShoppingZone.Models;

namespace EShoppingZone.Services
{
    public class RatingService : IRatingService
    {
        private readonly IRatingRepository _repository;
        private readonly IMapper _mapper;

        public RatingService(IRatingRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<ResponseDTO<RatingResponse>> AddRatingAsync(int profileId, RatingRequest ratingRequest)
        {
            if (ratingRequest.StarRating < 1 || ratingRequest.StarRating > 5)
            {
                return new ResponseDTO<RatingResponse>
                {
                    Success = false,
                    Message = "Star rating must be between 1 and 5."
                };
            }

            var product = await _repository.GetProductAsync(ratingRequest.ProductId);
            if (product == null)
            {
                return new ResponseDTO<RatingResponse>
                {
                    Success = false,
                    Message = "Product not found."
                };
            }

            var existingRating = await _repository.GetRatingAsync(ratingRequest.ProductId, profileId);
            if (existingRating != null)
            {
                return new ResponseDTO<RatingResponse>
                {
                    Success = false,
                    Message = "You have already rated this product."
                };
            }

            var rating = new Rating
            {
                ProductId = ratingRequest.ProductId,
                UserProfileId = profileId,
                StarRating = ratingRequest.StarRating,
                Review = ratingRequest.Review,
                CreatedAt = DateTime.UtcNow
            };

            await _repository.CreateRatingAsync(rating);
            product = await _repository.GetProductAsync(ratingRequest.ProductId);            
            product.AverageRating = product.Ratings.Any() ? (decimal)product.Ratings.Average(r => r.StarRating) : 0m;
            product.ReviewCount = product.Ratings.Count;
            await _repository.UpdateProductAsync(product);

            var response = _mapper.Map<RatingResponse>(rating);
            return new ResponseDTO<RatingResponse>
            {
                Success = true,
                Message = "Rating submitted successfully.",
                Data = response
            };
        }

        public async Task<RatingResponse[]> GetRatingsByProductAsync(int productId)
        {
            var ratings = await _repository.GetRatingsByProductAsync(productId);
            if(ratings == null){
                return null;
            }
            var response = _mapper.Map<RatingResponse[]>(ratings);
            return response;
        }
    }
}