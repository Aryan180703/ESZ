using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using EShoppingZone.DTOs;
using EShoppingZone.Services;
using EShoppingZone.Interfaces;
using EShoppingZone.DTOs.RatingDTOs;

namespace EShoppingZone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RatingController : ControllerBase
    {
        private readonly IRatingService _service;

        public RatingController(IRatingService service)
        {
            _service = service;
        }

        [HttpPost]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> AddRating([FromBody] RatingRequest ratingRequest)
        {
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? throw new UnauthorizedAccessException());
            var response = await _service.AddRatingAsync(profileId, ratingRequest);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet("product/{productId}")]
        public async Task<IActionResult> GetRatingsByProduct(int productId)
        {
            var response = await _service.GetRatingsByProductAsync(productId);
            if (response==null)
            {
                return BadRequest("Product doesn't exist");
            }
            return Ok(response);
        }
    }
}