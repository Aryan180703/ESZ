using System;
using System.Security.Claims;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.CartDTOs;
using EShoppingZone.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EShoppingZone.Controllers
{
    [Route("api/CartController")]
    [ApiController]
    [Authorize(Roles = "Customer")]
    public class CartController : ControllerBase
    {
        private readonly ICartService _service;

        public CartController(ICartService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> AddToCart([FromBody] CartRequest cartRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));   
            }
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.AddToCartAsync(profileId, cartRequest);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpPut("UpdateCart/{itemId}")]
        public async Task<IActionResult> UpdateCartItem(int itemId, [FromBody] UpdateCartItemRequest updateRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));   
            }
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.UpdateCartItemAsync(profileId, itemId, updateRequest);
            if (response.Success)
            {
                return Ok(response);
                }
            return BadRequest(response);
        }

        [HttpDelete("RemoveFromCart/{itemId}")]
        public async Task<IActionResult> RemoveFromCart(int itemId)
        {
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.RemoveFromCartAsync(profileId, itemId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet("GetCart")]
        public async Task<IActionResult> GetCart()
        {
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.GetCartAsync(profileId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpDelete("ClearCart")]
        public async Task<IActionResult> ClearCart()
        {
            var profileId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var response = await _service.ClearCartAsync(profileId);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }
    }
}