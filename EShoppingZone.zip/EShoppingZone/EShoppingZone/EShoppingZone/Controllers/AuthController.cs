using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.Interfaces;
using EShoppingZone.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace EShoppingZone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _service;

        public AuthController(IAuthService service)
        {
            _service = service;
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] RegisterDTO registerDto)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));
            }
            var response = await _service.RegisterAsync(registerDto);
            return Ok(response);
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginDTO loginDto)
        {
            var response = await _service.LoginAsync(loginDto);
            if (response == null)
            {
                return BadRequest("Invalid Email or Password");
            }
            response.Id = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            return Ok(response);
        }

        [HttpGet("GetUserName/{id}")]
        public async Task<IActionResult> GetUserDetails(int id)
        {
            var response = await _service.GetUserName(id);
            if (response == null)
            {
                return BadRequest("User not exist");
            }
            return Ok(response);
        }

        [Authorize]
        [HttpPut("UpdateProfile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequest updateProfileRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage)
                    .ToList();
                return BadRequest("Validation errors: " + string.Join("; ", errors));
            }
            var profileId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.UpdateProfileAsync(profileId, updateProfileRequest);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [Authorize]
        [HttpGet("ViewProfile")]
        public async Task<IActionResult> ViewProfile()
        {
            var profileId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.ViewProfile(profileId);
            return Ok(response);
        }

        [HttpPost("ConfirmEmail")]
        public async Task<IActionResult> ConfirmEmail([FromBody] ConfirmEmailRequest request)
        {
            var response = await _service.ConfirmEmailAsync(request.Email, request.Otp);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpPost("GenerateOTP")]
        public async Task<IActionResult> GenerateOtp([FromBody] GenerateOtpRequest request)
        {
            var response = await _service.GenerateOtpAsync(request.Email);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }
    }
}