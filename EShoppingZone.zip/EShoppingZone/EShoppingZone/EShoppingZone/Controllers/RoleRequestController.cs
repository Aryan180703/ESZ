using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EShoppingZone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleRequestController : ControllerBase
    {
        private readonly IUserRoleRequestService _service;

        public RoleRequestController(IUserRoleRequestService service)
        {
            _service = service;
        }

        [HttpPost("RequestRole")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> RequestRole([FromBody] string requestedRole)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.SubmitRoleRequestAsync(userId, requestedRole);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet("Status")]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> GetRequestStatus([FromQuery] string requestedRole)
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.GetRequestStatusAsync(userId, requestedRole);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpPost("ApproveRequest")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ApproveRequest(int requestId, [FromQuery] bool isApproved)
        {
            var adminId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var response = await _service.ApproveRequestAsync(requestId, adminId, isApproved);
            if (response.Success)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }
    }
}