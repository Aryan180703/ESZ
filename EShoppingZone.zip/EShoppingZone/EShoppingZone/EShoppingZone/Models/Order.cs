using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EShoppingZone.Models
{
    public class Order
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int CustomerId { get; set; }
        [Required]
        public int AddressId { get; set; }
        [Required]
        public decimal TotalPrice { get; set; }
        public string Status { get; set; } = "Placed";
        public DateTime OrderDate { get; set; }
        public UserProfile Customer { get; set; } = null!;
        public Address Address { get; set; } = null!;
        public List<OrderItem> Items { get; set; } = new();
    }
}