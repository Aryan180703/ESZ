using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.Data;
using EShoppingZone.Interfaces;
using EShoppingZone.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace EShoppingZone.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly EShoppingZoneDBContext _context;
        private readonly RoleManager<IdentityRole<int>> _roleManager;

        public OrderRepository(EShoppingZoneDBContext context, RoleManager<IdentityRole<int>> roleManager)
        {
            _context = context;
            _roleManager = roleManager;
        }

        public async Task<Order> CreateOrderAsync(Order order)
        {
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();
            return order;
        }

        public async Task<Order> GetOrderAsync(int orderId)
        {
            return await _context.Orders.Include(o => o.Items).FirstOrDefaultAsync(o => o.Id == orderId);
        }

        public async Task<List<Order>> GetAllOrdersAsync(int profileId, bool isMerchant)
        {
            if (isMerchant)
            {
                return await _context.Orders.Include(o => o.Items).ToListAsync();
            }
            return await _context.Orders.Include(o => o.Items).Where(o => o.CustomerId == profileId).ToListAsync();
        }

        public async Task UpdateOrderAsync(Order order)
        {
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();
        }

        public async Task<Cart> GetCartAsync(int cartId)
        {
            return await _context.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.Id == cartId);
        }

        public async Task<Address> GetAddressAsync(int addressId)
        {
            return await _context.Addresses.FindAsync(addressId);
        }

        public async Task<Product> GetProductAsync(int productId)
        {
            return await _context.Products.FindAsync(productId);
        }

        public async Task ClearCartAsync(Cart cart)
        {
            cart.Items.Clear();
            cart.TotalPrice = 0;
            _context.Carts.Update(cart);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> IsMerchantAsync(int profileId)
        {
            var userRoles = await _context.UserRoles
                .Where(ur => ur.UserId == profileId)
                .Select(ur => ur.RoleId)
                .ToListAsync();
            var merchantRole = await _roleManager.FindByNameAsync("Merchant");
            return userRoles.Contains(merchantRole.Id);
        }

        public async Task<bool> IsDeliveryAgentAsync(int profileId)
        {
            var userRoles = await _context.UserRoles
                .Where(ur => ur.UserId == profileId)
                .Select(ur => ur.RoleId)
                .ToListAsync();
            var deliveryAgentRole = await _roleManager.FindByNameAsync("Delivery Agent");
            return userRoles.Contains(deliveryAgentRole.Id);
        }
    }
}