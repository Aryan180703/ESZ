using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.Data;
using EShoppingZone.Interfaces;
using EShoppingZone.Models;
using Microsoft.EntityFrameworkCore;

namespace EShoppingZone.Repository
{
    public class UserRoleRequestRepository : IUserRoleRequestRepository
    {
        private readonly EShoppingZoneDBContext _context;

        public UserRoleRequestRepository(EShoppingZoneDBContext context)
        {
            _context = context;
        }

        public async Task<UserRoleRequest> CreateRequestAsync(UserRoleRequest request)
        {
            await _context.UserRoleRequests.AddAsync(request);
            await _context.SaveChangesAsync();
            return request;
        }

        public async Task<UserRoleRequest> GetRequestByUserIdAsync(int userId, string requestedRole)
        {
            return await _context.UserRoleRequests
                .FirstOrDefaultAsync(r => r.UserId == userId && r.RequestedRole == requestedRole);
        }

        public async Task<UserRoleRequest> GetRequestByIdAsync(int requestId)
        {
            return await _context.UserRoleRequests.FindAsync(requestId);
        }

        public async Task UpdateRequestAsync(UserRoleRequest request)
        {
            _context.UserRoleRequests.Update(request);
            await _context.SaveChangesAsync();
        }
    }
}