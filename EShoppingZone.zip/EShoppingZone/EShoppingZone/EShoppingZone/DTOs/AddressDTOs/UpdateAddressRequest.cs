using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EShoppingZone.DTOs.AddressDTOs
{
    public class UpdateAddressRequest
    {
        [Range(1, int.MaxValue, ErrorMessage = "House number must be a positive integer.")]
        public int HouseNumber { get; set; }

        [StringLength(100, ErrorMessage = "Street name cannot exceed 100 characters.")]
        public string? StreetName { get; set; }

        [StringLength(100, ErrorMessage = "Colony name cannot exceed 100 characters.")]
        public string? ColonyName { get; set; }

        [Required(ErrorMessage = "City is required.")]
        [StringLength(50, ErrorMessage = "City name cannot exceed 50 characters.")]
        public string City { get; set; }

        [Required(ErrorMessage = "State is required.")]
        [StringLength(50, ErrorMessage = "State name cannot exceed 50 characters.")]
        public string State { get; set; }

        [Range(100000, 999999, ErrorMessage = "Pincode must be a 6-digit number.")]
        public int Pincode { get; set; }
    }
}
