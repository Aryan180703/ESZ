using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EShoppingZone.DTOs.RatingDTOs
{
    public class RatingResponse
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int UserProfileId { get; set; }
        public int StarRating { get; set; }
        public string? Review { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}