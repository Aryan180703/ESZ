using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EShoppingZone.DTOs.OrderDTOs
{
    public class OrderRequest
    {
        [Required(ErrorMessage = "Cart ID is required")]
        public int CartId { get; set; }

        [Required(ErrorMessage = "Address ID is required")]
        public int AddressId { get; set; }
    }
}