using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.Data;
using EShoppingZone.Models;

namespace EShoppingZone.Interfaces
{
    public interface IUserRoleRequestRepository
    {
        Task<UserRoleRequest> CreateRequestAsync(UserRoleRequest request);
        Task<UserRoleRequest> GetRequestByUserIdAsync(int userId, string requestedRole);
        Task<UserRoleRequest> GetRequestByIdAsync(int requestId);
        Task UpdateRequestAsync(UserRoleRequest request);
    }
}