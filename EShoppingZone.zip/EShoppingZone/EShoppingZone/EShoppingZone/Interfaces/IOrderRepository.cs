using System.Collections.Generic;
using System.Threading.Tasks;
using EShoppingZone.Models;

namespace EShoppingZone.Interfaces
{
    public interface IOrderRepository
    {
        Task<Order> CreateOrderAsync(Order order);
        Task<Order> GetOrderAsync(int orderId);
        Task<List<Order>> GetAllOrdersAsync(int profileId, bool isMerchant);
        Task UpdateOrderAsync(Order order);
        Task<Cart> GetCartAsync(int cartId);
        Task<Address> GetAddressAsync(int addressId);
        Task<Product> GetProductAsync(int productId);
        Task ClearCartAsync(Cart cart);
        Task<bool> IsMerchantAsync(int profileId);
        Task<bool> IsDeliveryAgentAsync(int profileId);
    }
}