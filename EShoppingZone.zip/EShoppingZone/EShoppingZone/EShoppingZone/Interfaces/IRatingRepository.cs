using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.Models;

namespace EShoppingZone.Interfaces
{
    public interface IRatingRepository
    {
        Task<Rating> GetRatingAsync(int productId, int userProfileId);
        Task CreateRatingAsync(Rating rating);
        Task<List<Rating>> GetRatingsByProductAsync(int productId);
        Task<Product> GetProductAsync(int productId);
        Task UpdateProductAsync(Product product);
    }
}
