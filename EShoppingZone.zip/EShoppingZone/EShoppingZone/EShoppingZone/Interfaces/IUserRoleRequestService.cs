using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.DTOs;

namespace EShoppingZone.Interfaces
{
    public interface IUserRoleRequestService
    {
        Task<ResponseDTO<string>> SubmitRoleRequestAsync(int userId, string requestedRole);
        Task<ResponseDTO<string>> GetRequestStatusAsync(int userId, string requestedRole);
        Task<ResponseDTO<string>> ApproveRequestAsync(int requestId, int adminId, bool isApproved);
    }
}