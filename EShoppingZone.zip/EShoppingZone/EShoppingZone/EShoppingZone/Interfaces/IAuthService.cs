using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.DTOs;

namespace EShoppingZone.Interfaces
{
    public interface IAuthService
    {
        Task<AuthResponseDTO> RegisterAsync(RegisterDTO registerDto);
        Task<AuthResponseDTO> LoginAsync(LoginDTO loginDto);
        // Task SendWelcomeEmailAsync(string email);
        // Task <ResponseDTO<string>> ForgotPasswordAsync(string email);
        Task<ResponseDTO<ProfileResponse>> UpdateProfileAsync(int profileId, UpdateProfileRequest updateProfileRequest);
        Task<ResponseDTO<ProfileResponse>> ViewProfile(int prrofileId);
        Task<ResponseDTO<string>> ConfirmEmailAsync(string email, string otp);
        Task<ResponseDTO<string>> GenerateOtpAsync(string email);
        Task<ProfileDetails> GetUserName(int id);
    }
}