using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EShoppingZone.DTOs;
using EShoppingZone.DTOs.RatingDTOs;

namespace EShoppingZone.Interfaces
{
    public interface IRatingService
    {
        Task<ResponseDTO<RatingResponse>> AddRatingAsync(int profileId, RatingRequest ratingRequest);
        Task<RatingResponse[]> GetRatingsByProductAsync(int productId);
    }
}